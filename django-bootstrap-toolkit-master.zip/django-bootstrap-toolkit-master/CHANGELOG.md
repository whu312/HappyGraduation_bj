CHANGELOG
=========

2013-11-18 
* Upgrade eternicode/bootstrap-datepicker - issue #105

2013-06-28
* New template tag `bootstrap_button`
* Minor code cleanups
* Updated datepicker to latest version
* Started changelog
